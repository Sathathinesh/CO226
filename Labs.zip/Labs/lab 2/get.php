<html>
<body>
<style>
div{
	border: 1px solid black;
	margin-left: 0px;
	margin-right:800px;
	margin-top:0px;
	margin-bottom:0px;
	padding:0px 10px 25px 25px;
}
</style>
<div><h1>Your Information System</h1>

<?php

	//echo "<div>";
	if (isset($_GET['size'])){
		$size=$_GET['size'];
	}
	else{
		$size='';
	}
	
	if(isset($_GET['cap'])){
		$cap=$_GET['cap'];
	}
	else{
		$cap='';
	}
	if(isset($_GET['wristband'])){
		$wristband=$_GET['wristband'];
	}
	else{
		$wristband='';
	}
	
	$color=$_GET['color'];
	
	$firstName=$_GET['firstName'];
	$lastName=$_GET['lastName'];
	$address1=$_GET['address1'];
	$address2=$_GET['address2'];
	$address3=$_GET['address3'];
	
	echo "Thank you, ".$firstName." for your perches from our website";
	echo "<p>Your item colour is: ".$color." & T-Shirt size : ".$size."</p>";
	
	if(isset($_GET['cap'])&&isset($_GET['wristband'])){
		echo "<p>Selected items/item are :</p>";
		echo "<p>*".$cap."</p>";
		echo "<p>*".$wristband."</p>";
	}
	else if(isset($_GET['cap'])){
		echo "<p>Selected items/item are :</p>";
		echo "<p>*".$cap."</p>";
	}
	else if(isset($_GET['wristband'])){
		echo "<p>Selected items/item are :</p>";
		echo "<p>*".$wristband."</p>";
	}
	else{
		echo "<p>Selected items/item are :</p>";
	}
	echo "<p>Your items will be sent to : </p>";
	echo "<i><p>".$firstName." ".$lastName."</p>";
	echo "<p>".$address1."</p>";
	echo "<p>".$address2."</p>";
	echo "<p>".$address3."</p></i>";
	
	$comments=$_GET['comments'];
	echo "<p>Thank you for submitting your comments. We appreciate it. You said :</p>";
	echo "<p><i>".$comments."</i></p></div>";

?>
</body>
</html>